function loadConfig(data) {
  IndexObj.init(data);
}

const IndexObj = {
  currentOption: "",
  loginOptions: [],

  LOGIN_OPTION: {
    VOUCHER: "voucher",
    FIXACCOUNT: "fixaccount",
    PASS: "pass",
  },

  init: function (data) {
    if (PortalActions.resume()) return;
    this.loadJson(data);
    this.initEvent();
    PortalLoader.finish();
  },

  loadJson: function (data) {
    I18nObj.init(data);
    this.renderHtml(data);
  },

  initEvent: function () {
    const self = this;
    $("#login_btn").on("click", function () {
      self.onLogin(null);
    });
    $(".grid a.item").on("click", function (e) {
      e.preventDefault();
      self.onLogin(this.getAttribute("href"));
    });
  },

  renderHtml: function (data) {
    const loginOptions = data?.custom_html?.login_options;
    this.loginOptions = loginOptions;

    if (!loginOptions) {
      return false;
    }

    // Define priority order
    const priorityOrder = [
      this.LOGIN_OPTION.VOUCHER,
      this.LOGIN_OPTION.FIXACCOUNT,
      this.LOGIN_OPTION.PASS,
    ];
    let currentOption = null;

    // Search for the default option according to the priority order
    for (const option of priorityOrder) {
      if (loginOptions.includes(option)) {
        currentOption = option;
        this.currentOption = currentOption;
        break;
      }
    }

    if (!currentOption) {
      return false;
    }

    I18nObj.renderHtmlLang();
    this.renderLoginHtml(loginOptions);
    this.renderCurrentLogin(currentOption);
  },

  renderHtmlLang: function () {},

  renderLoginHtml: function (loginOptions) {
    // Control priority through styles: Voucher > Account > Oneclick
    if (loginOptions.length > 1) {
      $("#login_split_line").removeClass("hide");
    }

    const allOptions = [
      this.LOGIN_OPTION.VOUCHER,
      this.LOGIN_OPTION.FIXACCOUNT,
      this.LOGIN_OPTION.PASS,
    ];
    const missOptions = allOptions.filter(
      (option) => !loginOptions.includes(option)
    );

    missOptions.forEach((item) => {
      $(`.login-item-${item}`).remove();
    });
  },

  renderCurrentLogin(currentOption) {
    switch (currentOption) {
      case this.LOGIN_OPTION.PASS:
        $(".login-form-title").text(I18nObj.$t("one_click_login"));
        $('.login-form-title').attr('data-i18n', 'one_click_login')
        break;
      case this.LOGIN_OPTION.FIXACCOUNT:
        $(".login-form-title").text(I18nObj.$t("account_login"));
        $('.login-form-title').attr('data-i18n', 'account_login')
        break;
      case this.LOGIN_OPTION.VOUCHER:
      default:
        $(".login-form-title").text(I18nObj.$t("voucher_login"));
        $('.login-form-title').attr('data-i18n', 'voucher_login')
    }

    const loginOptions = this.loginOptions;
    $(".login-form-wrapper .login-item").addClass("hide");
    $(".login-form-wrapper .login-item-" + currentOption).removeClass("hide");

    $(".other-btn-wrapper .login-item").addClass("hide");
    loginOptions.forEach((loginOpt) => {
      if (loginOpt !== currentOption) {
        $(".other-btn-wrapper .login-item-" + loginOpt).removeClass("hide");
      }
    });
  },

  changeLoginOption(currentOption) {
    this.currentOption = currentOption;
    this.renderCurrentLogin(currentOption);
  },

  setButtonState(state) {
    const labels = {
      loading: "Đang kết nối…",
      success: "Đã kết nối",
      error: "Thử kết nối lại",
      idle: "Kết nối WiFi →"
    };
    $("#login_btn").attr("data-state", state)
      .attr("aria-busy", state === "loading" ? "true" : "false")
      .text(labels[state] || labels.idle);
  },

  onLogin(destination) {
    if (this.loginPending) return false;
    let paramObj = {};

    switch (this.currentOption) {
      case this.LOGIN_OPTION.FIXACCOUNT:
        paramObj.account = $("#account_input").val();
        paramObj.password = $("#account_password").val();
        break;
      case this.LOGIN_OPTION.VOUCHER:
        paramObj.account = $("#voucher_code").val();
      case this.LOGIN_OPTION.PASS:
        break;
    }

    const validRes = this.validateLoginForm();
    if (!validRes) {
      return false;
    }

    paramObj = {
      lang: I18nObj.currentLang,
      authType: this.currentOption,
      sessionId: this._getParamVal("sessionId"),
      ...paramObj,
    };

    const self = this;
    self.loginPending = true;
    $("#login_btn").prop("disabled", true);
    $(".grid").attr("aria-busy", "true");
    $("#login_msg").text("");
    self.setButtonState("loading");
    function release(message) {
      self.loginPending = false;
      $("#login_btn").prop("disabled", false);
      $(".grid").attr("aria-busy", "false");
      self.setButtonState("error");
      $("#login_msg").text(message);
    }
    $.post({
      timeout: 20000,
      url: "/api/auth/general",
      data: JSON.stringify(paramObj),
      contentType: "application/json",
      success: function (response) {
        if (response && response.success && response.result && response.result.logonUrl) {
          try {
            // Always visit the gateway logon URL; API success alone is not Internet access.
            const nextUrl = PortalActions.logonUrl(response.result.logonUrl, destination);
            self.setButtonState("success");
            // Short visual acknowledgement only; gateway navigation still completes login.
            setTimeout(function () { location.href = nextUrl; }, 650);
          } catch (err) {
            release(err.message);
          }
        } else {
          release((response && response.message) || "Chưa kết nối được. Vui lòng thử lại.");
        }
      },
      error: function () {
        release("Kết nối bị gián đoạn. Vui lòng thử lại.");
      },
    });
  },

  validateLoginForm() {
    $("#login_msg").text("");
    if (!this.currentOption) {
      return true;
    }

    switch (this.currentOption) {
      case this.LOGIN_OPTION.PASS:
        break;
      case this.LOGIN_OPTION.FIXACCOUNT:
        return this.validateAccountForm();
      case this.LOGIN_OPTION.VOUCHER:
      default:
        return this.validateVoucherForm();
    }

    return true;
  },

  validateVoucherForm() {
    const voucherCode = $("#voucher_code").val().trim();
    if (!voucherCode) {
      $("#login_msg").text(I18nObj.$t("please_enter_access_code"));
      return false;
    }
    return true;
  },

  validateAccountForm() {
    const accountVal = $("#account_input").val().trim();
    const accountPwd = $("#account_password").val().trim();
    if (!accountVal) {
      $("#login_msg").text(I18nObj.$t("please_enter_account"));
      return false;
    }
    if (!accountPwd) {
      $("#login_msg").text(I18nObj.$t("please_enter_pwd"));
      return false;
    }
    return true;
  },

  _getParamVal(paras) {
    try {
      let href = window.location.href;
      try { href = window.top.location.href; } catch (_) {}
      const params = new URL(href).searchParams;
      for (const [key, value] of params) {
        if (key.toLowerCase() === paras.toLowerCase()) return value;
      }
      return null;
    } catch (e) {
      console.error("Error accessing top window URL:", e);
      return null;
    }
  },
};
