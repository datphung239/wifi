/* v2.1: fade only after login controls have been initialized. */
var PortalLoader = (function () {
  var started = Date.now(), finished = false;
  document.documentElement.classList.add('portal-loading');
  var watchdog = setTimeout(function () {
    if (finished) return;
    var status = document.getElementById('splash_status');
    var retry = document.getElementById('splash_retry');
    if (status) status.textContent = 'Trang WiFi tải lâu hơn dự kiến. Vui lòng thử lại.';
    if (retry) retry.hidden = false;
    document.documentElement.classList.add('portal-load-error');
  }, 12000);
  return {
    finish: function () {
      if (finished) return;
      finished = true;
      clearTimeout(watchdog);
      var logo = document.querySelector('.splash-logo');
      var ready = logo && logo.decode ? logo.decode().catch(function () {}) : Promise.resolve();
      Promise.race([ready, new Promise(function (resolve) { setTimeout(resolve, 500); })]).then(function () {
        setTimeout(function () {
          document.documentElement.classList.remove('portal-loading');
          document.documentElement.classList.add('portal-ready');
          setTimeout(function () {
            var overlay = document.getElementById('body_loading');
            if (overlay) overlay.hidden = true;
          }, 500);
        }, Math.max(0, 450 - (Date.now() - started)));
      });
    }
  };
})();
