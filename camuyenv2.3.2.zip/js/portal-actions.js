/* v2.2 EXPERIMENTAL: append url for observed /wifidog/auth gateway.
 * url is used by some WiFiDog implementations; Reyee support remains unverified.
 * Preserve main connect URL exactly. Always navigate through gateway authentication.
 */
const PortalActions = {
  allowed: [
    'https://khachsancamuyen.com',
    'https://maps.app.goo.gl/4q1NxXP1J76Tsw7m7?g_st=ac',
    'https://drive.google.com/drive/folders/1FBLAdt5fZyoaZmUA2Tsp32ZTdLYNlRRh',
    'tel:0334727969'
  ],
  logonUrl(raw, destination) {
    const gateway = new URL(raw, window.location.href);
    if (!/^https?:$/.test(gateway.protocol)) throw new Error('Địa chỉ đăng nhập không hợp lệ.');
    if (destination && !this.allowed.includes(destination)) throw new Error('Liên kết không được hỗ trợ.');
    if (!destination) return raw;
    const keys = Array.from(gateway.searchParams.keys());
    let returnKey = keys.find(key => /^(url|redirect_url|redirecturl|post_url|posturl|next_url|nexturl)$/i.test(key));
    if (!returnKey && /^\/wifidog\/auth\/?$/.test(gateway.pathname)) {
      returnKey = 'url';
    }
    if (!returnKey) {
      throw new Error('Chưa hỗ trợ chuyển trang với địa chỉ đăng nhập này. Vui lòng dùng nút Kết nối WiFi.');
    }
    let target = destination;
    if (!destination || destination.indexOf('tel:') === 0) {
      // Gateways usually require an HTTP(S) return URL, not a tel: redirect.
      const callback = new URL(window.location.href);
      callback.hash = destination ? 'camuyen-call' : 'camuyen-close';
      target = callback.href;
    }
    gateway.searchParams.set(returnKey, target);
    return gateway.href;
  },
  resume() {
    if (window.location.hash === '#camuyen-close') {
      PortalLoader.finish();
      $('#login_msg').text('Đã hoàn tất bước đăng nhập. Quý khách có thể đóng cửa sổ này.');
      $('#login_btn').text('Đóng cửa sổ').on('click', function () { window.close(); });
      $('.grid a.item').removeAttr('target');
      window.close(); // Best effort: browser/OS owns captive-window dismissal.
      return true;
    }
    if (window.location.hash !== '#camuyen-call') return false;
    PortalLoader.finish();
    $('#login_msg').text('Nếu điện thoại chưa mở màn hình gọi, nhấn Gọi lễ tân bên dưới.');
    $('#login_btn').text('Gọi lễ tân · 0334 727 969').on('click', function () {
      window.location.href = 'tel:0334727969';
    });
    // Keep direct links usable if a captive browser requires another user gesture.
    $('.grid a.item').removeAttr('target');
    window.location.href = 'tel:0334727969';
    return true;
  }
};
