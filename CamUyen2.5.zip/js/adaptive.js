/* Accessibility-first compact mode for small captive popups with very large text.
 * This only removes decorative header elements when the main action is below the fold.
 * No scaling, click handling or Ruijie gateway logic is changed. */
(function () {
  var queued = false;
  function chooseLayout() {
    queued = false;
    var html = document.documentElement;
    var button = document.getElementById('login_btn');
    if (!button) return;
    html.classList.remove('cu-compact-priority');
    var height = window.visualViewport ? window.visualViewport.height : window.innerHeight;
    var width = window.visualViewport ? window.visualViewport.width : window.innerWidth;
    var bounds = button.getBoundingClientRect();
    if (width <= 480 && bounds.bottom > height - 20) {
      html.classList.add('cu-compact-priority');
    }
  }
  function schedule() {
    if (queued) return;
    queued = true;
    if (window.requestAnimationFrame) requestAnimationFrame(chooseLayout);
    else setTimeout(chooseLayout, 0);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', schedule);
  else schedule();
  window.addEventListener('load', schedule);
  window.addEventListener('resize', schedule);
  window.addEventListener('orientationchange', schedule);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', schedule);
})();
